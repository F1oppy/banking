package com.wipro.OnlineBanking;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface NEFTTransactionRepository extends MongoRepository < NEFTTransaction, String>{

}
